#Thanks for all contributions!

#Authors
chucktheripper  
0Lucifer0  
Ciapa  
genyx  
MasterDomino  
Martazza  
KrisYiu  
Uppermost  

#Helpers
juhgiyo for his JPS+ algorithm  
Medhy for encryptions algorithm  
flowx3 for HP algorithm  
Elektrochemie for encryptions algorithm
